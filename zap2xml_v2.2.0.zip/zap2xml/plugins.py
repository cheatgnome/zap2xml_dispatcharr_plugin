# Display metadata for Dispatcharr plugin registry/UI
__all__ = ['PLUGIN_KEY', 'PLUGIN_NAME', 'PLUGIN_VERSION']
PLUGIN_KEY = 'zap2xml'
PLUGIN_NAME = 'Zap2XML'
PLUGIN_VERSION = '1.9.13'
__version__ = PLUGIN_VERSION
version = PLUGIN_VERSION
